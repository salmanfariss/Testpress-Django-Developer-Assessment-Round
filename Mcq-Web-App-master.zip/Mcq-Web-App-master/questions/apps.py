from django.apps import AppConfig


class QDbConfig(AppConfig):
    name = 'questions'
